﻿namespace Ex03.ConsoleUI
{
    class Program
    {
        public static void Main()
        {
            GarageUI.UI();
        }
    }
}
